export interface Produto {
  nome:         string;
  descricao:    string;
  codigoBarras: string;
  fabricanteID: number;
}