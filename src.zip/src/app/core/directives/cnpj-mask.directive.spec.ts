import { CnpjMaskDirective } from './cnpj-mask.directive';

describe('CnpjMaskDirective', () => {
  it('should create an instance', () => {
    const directive = new CnpjMaskDirective();
    expect(directive).toBeTruthy();
  });
});
