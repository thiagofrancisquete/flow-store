import { Pessoa } from 'src/app/models/pessoa-model';
import { FabricantesService } from './../../../services/fabricantes.service';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { SharedPessoaService } from 'src/app/shared/services/shared-pessoa.service';

@Component({
  selector: 'app-fabricantes-table',
  templateUrl: './fabricantes-table.component.html',
  styleUrls: ['./fabricantes-table.component.scss']
})
export class FabricantesTableComponent implements OnInit, AfterViewInit {

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort!: MatSort;

  dataSource!:  MatTableDataSource<any>
  displayedColumns: string[] = ['nome', 'cnpj', 'endereco', 'actions']
  pageSizeOptions: number[] = [1, 2, 5, 10];

  pageSize: number = 5; // Tamanho de página padrão
  pageNumber: number = 0; // Número da página padrão
  totalElements: number = 0; // Total de elementos padrão
  totalPages: number = 0; // Total de páginas padrão

  cnpjInput!: number;
  ascendingEnderecoOrder = true;

  constructor(private fabricantesService: FabricantesService, private router: Router, private sharedPessoaService: SharedPessoaService) {}

   fakeData = {
    "content": [
      {
        "id": 1,
        "nome": "Voltta",
        "cnpj": "47944006000189",
        "cep": "04551010",
        "logradouro": "Rua Fidêncio Ramos",
        "numero": "308",
        "complemento": "1 andar",
        "bairro": "Vila Olímpia",
        "cidade": "São Paulo",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "contato@voltta.com.br"
      },
      {
        "id": 2,
        "nome": "Mc Donald's",
        "cnpj": "17944006000189",
        "cep": "12040000",
        "logradouro": "Washington Luís",
        "numero": "455",
        "complemento": "de 283 ao fim - lado ímpar",
        "bairro": "Boqueirão",
        "cidade": "Santos",
        "estado": "São Paulo",
        "contatoTipo": "Telefone",
        "contato": "1233025050"
      },
      {
        "id": 3,
        "nome": "Armani",
        "cnpj": "17944006000121",
        "cep": "12233480",
        "logradouro": "Rua Mirassol",
        "numero": "45",
        "complemento": "",
        "bairro": "Bosque dos Eucaliptos",
        "cidade": "São José dos Campos",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "sjc@sjc.com.br"
      },
      {
        "id": 4,
        "nome": "Voltta",
        "cnpj": "47944006000180",
        "cep": "04551010",
        "logradouro": "Rua Fidêncio Ramos",
        "numero": "308",
        "complemento": "1 andar",
        "bairro": "Vila Olímpia",
        "cidade": "São Paulo",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "contato@voltta.com.br"
      },
      {
        "id": 1,
        "nome": "Voltta",
        "cnpj": "47944006000180",
        "cep": "04551010",
        "logradouro": "Rua Fidêncio Ramos",
        "numero": "308",
        "complemento": "1 andar",
        "bairro": "Vila Olímpia",
        "cidade": "São Paulo",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "contato@voltta.com.br"
      },
      {
        "id": 2,
        "nome": "Carrefour",
        "cnpj": "17944006000189",
        "cep": "12040000",
        "logradouro": "Avenida Charles Schnneider",
        "numero": "308",
        "complemento": "(Bosque Flamboyant)",
        "bairro": "Parque Senhor do Bonfim",
        "cidade": "Taubaté",
        "estado": "São Paulo",
        "contatoTipo": "Telefone",
        "contato": "1233025050"
      },
      {
        "id": 3,
        "nome": "Armani",
        "cnpj": "17944006000121",
        "cep": "12233480",
        "logradouro": "Rua Mirassol",
        "numero": "45",
        "complemento": "",
        "bairro": "Bosque dos Eucaliptos",
        "cidade": "São José dos Campos",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "sjc@sjc.com.br"
      },
      {
        "id": 4,
        "nome": "Voltta",
        "cnpj": "47944006000180",
        "cep": "04551010",
        "logradouro": "Rua Fidêncio Ramos",
        "numero": "308",
        "complemento": "1 andar",
        "bairro": "Vila Olímpia",
        "cidade": "São Paulo",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "contato@voltta.com.br"
      },
      {
        "id": 1,
        "nome": "Voltta",
        "cnpj": "47944006000180",
        "cep": "04551010",
        "logradouro": "Rua Fidêncio Ramos",
        "numero": "308",
        "complemento": "1 andar",
        "bairro": "Vila Olímpia",
        "cidade": "São Paulo",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "contato@voltta.com.br"
      },
      {
        "id": 2,
        "nome": "Carrefour",
        "cnpj": "17944006000189",
        "cep": "12040000",
        "logradouro": "Avenida Charles Schnneider",
        "numero": "308",
        "complemento": "(Bosque Flamboyant)",
        "bairro": "Parque Senhor do Bonfim",
        "cidade": "Taubaté",
        "estado": "São Paulo",
        "contatoTipo": "Telefone",
        "contato": "1233025050"
      },
      {
        "id": 3,
        "nome": "Armani",
        "cnpj": "17944006000121",
        "cep": "12233480",
        "logradouro": "Rua Mirassol",
        "numero": "45",
        "complemento": "",
        "bairro": "Bosque dos Eucaliptos",
        "cidade": "São José dos Campos",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "sjc@sjc.com.br"
      },
      {
        "id": 4,
        "nome": "Voltta",
        "cnpj": "47944006000180",
        "cep": "04551010",
        "logradouro": "Rua Fidêncio Ramos",
        "numero": "308",
        "complemento": "1 andar",
        "bairro": "Vila Olímpia",
        "cidade": "São Paulo",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "contato@voltta.com.br"
      },
      {
        "id": 1,
        "nome": "Voltta",
        "cnpj": "47944006000180",
        "cep": "04551010",
        "logradouro": "Rua Fidêncio Ramos",
        "numero": "308",
        "complemento": "1 andar",
        "bairro": "Vila Olímpia",
        "cidade": "São Paulo",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "contato@voltta.com.br"
      },
      {
        "id": 2,
        "nome": "Carrefour",
        "cnpj": "17944006000189",
        "cep": "12040000",
        "logradouro": "Avenida Charles Schnneider",
        "numero": "308",
        "complemento": "(Bosque Flamboyant)",
        "bairro": "Parque Senhor do Bonfim",
        "cidade": "Taubaté",
        "estado": "São Paulo",
        "contatoTipo": "Telefone",
        "contato": "1233025050"
      },
      {
        "id": 3,
        "nome": "Armani",
        "cnpj": "17944006000121",
        "cep": "12233480",
        "logradouro": "Rua Mirassol",
        "numero": "45",
        "complemento": "",
        "bairro": "Bosque dos Eucaliptos",
        "cidade": "São José dos Campos",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "sjc@sjc.com.br"
      },
      {
        "id": 4,
        "nome": "Voltta",
        "cnpj": "47944006000180",
        "cep": "04551010",
        "logradouro": "Rua Fidêncio Ramos",
        "numero": "308",
        "complemento": "1 andar",
        "bairro": "Vila Olímpia",
        "cidade": "São Paulo",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "contato@voltta.com.br"
      },
      {
        "id": 1,
        "nome": "Voltta",
        "cnpj": "47944006000180",
        "cep": "04551010",
        "logradouro": "Rua Fidêncio Ramos",
        "numero": "308",
        "complemento": "1 andar",
        "bairro": "Vila Olímpia",
        "cidade": "São Paulo",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "contato@voltta.com.br"
      },
      {
        "id": 2,
        "nome": "Carrefour",
        "cnpj": "17944006000189",
        "cep": "12040000",
        "logradouro": "Avenida Charles Schnneider",
        "numero": "308",
        "complemento": "(Bosque Flamboyant)",
        "bairro": "Parque Senhor do Bonfim",
        "cidade": "Taubaté",
        "estado": "São Paulo",
        "contatoTipo": "Telefone",
        "contato": "1233025050"
      },
      {
        "id": 3,
        "nome": "Armani",
        "cnpj": "17944006000121",
        "cep": "12233480",
        "logradouro": "Rua Mirassol",
        "numero": "45",
        "complemento": "",
        "bairro": "Bosque dos Eucaliptos",
        "cidade": "São José dos Campos",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "sjc@sjc.com.br"
      },
      {
        "id": 4,
        "nome": "Voltta",
        "cnpj": "47944006000180",
        "cep": "04551010",
        "logradouro": "Rua Fidêncio Ramos",
        "numero": "308",
        "complemento": "1 andar",
        "bairro": "Vila Olímpia",
        "cidade": "São Paulo",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "contato@voltta.com.br"
      },
      {
        "id": 1,
        "nome": "Voltta",
        "cnpj": "47944006000180",
        "cep": "04551010",
        "logradouro": "Rua Fidêncio Ramos",
        "numero": "308",
        "complemento": "1 andar",
        "bairro": "Vila Olímpia",
        "cidade": "São Paulo",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "contato@voltta.com.br"
      },
      {
        "id": 2,
        "nome": "Carrefour",
        "cnpj": "17944006000189",
        "cep": "12040000",
        "logradouro": "Avenida Charles Schnneider",
        "numero": "308",
        "complemento": "(Bosque Flamboyant)",
        "bairro": "Parque Senhor do Bonfim",
        "cidade": "Taubaté",
        "estado": "São Paulo",
        "contatoTipo": "Telefone",
        "contato": "1233025050"
      },
      {
        "id": 3,
        "nome": "Armani",
        "cnpj": "17944006000121",
        "cep": "12233480",
        "logradouro": "Rua Mirassol",
        "numero": "45",
        "complemento": "",
        "bairro": "Bosque dos Eucaliptos",
        "cidade": "São José dos Campos",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "sjc@sjc.com.br"
      },
      {
        "id": 4,
        "nome": "Voltta",
        "cnpj": "47944006000180",
        "cep": "04551010",
        "logradouro": "Rua Fidêncio Ramos",
        "numero": "308",
        "complemento": "1 andar",
        "bairro": "Vila Olímpia",
        "cidade": "São Paulo",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "contato@voltta.com.br"
      },
      {
        "id": 1,
        "nome": "Voltta",
        "cnpj": "47944006000180",
        "cep": "04551010",
        "logradouro": "Rua Fidêncio Ramos",
        "numero": "308",
        "complemento": "1 andar",
        "bairro": "Vila Olímpia",
        "cidade": "São Paulo",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "contato@voltta.com.br"
      },
      {
        "id": 2,
        "nome": "Carrefour",
        "cnpj": "17944006000189",
        "cep": "12040000",
        "logradouro": "Avenida Charles Schnneider",
        "numero": "308",
        "complemento": "(Bosque Flamboyant)",
        "bairro": "Parque Senhor do Bonfim",
        "cidade": "Taubaté",
        "estado": "São Paulo",
        "contatoTipo": "Telefone",
        "contato": "1233025050"
      },
      {
        "id": 3,
        "nome": "Armani",
        "cnpj": "17944006000121",
        "cep": "12233480",
        "logradouro": "Rua Mirassol",
        "numero": "45",
        "complemento": "",
        "bairro": "Bosque dos Eucaliptos",
        "cidade": "São José dos Campos",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "sjc@sjc.com.br"
      },
      {
        "id": 4,
        "nome": "Voltta",
        "cnpj": "47944006000180",
        "cep": "04551010",
        "logradouro": "Rua Fidêncio Ramos",
        "numero": "308",
        "complemento": "1 andar",
        "bairro": "Vila Olímpia",
        "cidade": "São Paulo",
        "estado": "São Paulo",
        "contatoTipo": "Email",
        "contato": "contato@voltta.com.br"
      }
    ],
    "pageable": {
      "pageNumber": 0,
      "pageSize": 1,
      "sort": {
        "empty": false,
        "sorted": true,
        "unsorted": false
      },
      "offset": 0,
      "paged": true,
      "unpaged": false
    },
    "totalPages": 1,
    "totalElements": 4,
    "last": true,
    "size": 1,
    "number": 0,
    "sort": {
      "empty": false,
      "sorted": true,
      "unsorted": false
    },
    "numberOfElements": 4,
    "first": true,
    "empty": false
  }

  ngOnInit(): void {
    this.getFabricantes()
  }

  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
  }

  getFabricantes() {
    this.dataSource = new MatTableDataSource(this.fakeData.content)
    this.pageSize = this.fakeData.pageable.pageSize;
    this.pageNumber = this.fakeData.pageable.pageNumber;
    this.totalElements = this.fakeData.totalElements;
    this.totalPages = this.fakeData.totalPages;

    // console.log(this.pageSize, this.pageNumber)

    /*
    this.fabricantesService.getPessoa().subscribe({
      next: res => {
        console.log('Fabricantes: ', res);
        this.dataSource = new MatTableDataSource(res.content);
        this.pageSize = res.pageable.pageSize;
        this.pageNumber = res.pageable.pageNumber;
        this.totalElements = res.totalElements;
        this.totalPages = res.totalPages;
      },
      error: err => {
        console.log('Erro ao buscar dados do servidor', err);
      }
    });
    */
  }

  paginar(event: any) {
    console.log(event)
    this.pageSize = event.pageSize;
    this.pageNumber = event.pageIndex;
    this.getFabricantes(); // Chama novamente o método para buscar os dados com base na nova página selecionada
  }

  create() {
    this.router.navigate(['fabricantes/cadastrar-fabricante'])
  }

  exclude(row: Pessoa) {
    console.log(row.id)
  }


  edit(row: Pessoa) {
    this.sharedPessoaService.setPessoa(row)
    this.router.navigate([`fabricantes/editar-fabricante/${row.id}`])
  }


  searchCnpj() {
    console.log(this.cnpjInput)

    this.fabricantesService.getPessoaByCnpj(this.cnpjInput, 0, 5).subscribe({
      next: res => {
        console.log(res)
      },
      error: err => {
        console.log(err)
      }
    })
  }

  sortDataByNome() {
    // compara os valores da tabela ASCII de cada caractere nas strings a.nome e b.nome e determina a ordem alfabética com base nisso
    this.dataSource.data.sort((a, b) => a.nome.localeCompare(b.nome));
     // garante que as alterações nos dados sejam refletidas na exibição da tabela
    this.dataSource._updateChangeSubscription();
  }

  sortDataByCnpj() {
    this.dataSource.data.sort((a, b) => a.cnpj.localeCompare(b.cnpj));
    this.dataSource._updateChangeSubscription();
  }

  sortDataByEndereco() {
    if (this.ascendingEnderecoOrder) {
      this.dataSource.data.sort((a, b) => a.logradouro.localeCompare(b.logradouro));
    } else {
      this.dataSource.data.sort((a, b) => b.logradouro.localeCompare(a.logradouro));
    }
    this.ascendingEnderecoOrder = !this.ascendingEnderecoOrder; // Alternar a direção da ordenação
    this.dataSource._updateChangeSubscription();
  }

}
