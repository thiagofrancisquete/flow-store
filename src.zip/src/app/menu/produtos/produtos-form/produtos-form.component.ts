import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-produtos-form',
  templateUrl: './produtos-form.component.html',
  styleUrls: ['./produtos-form.component.scss']
})
export class ProdutosFormComponent {
  produtosForm!: FormGroup;


  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.buildForm();
  }

  buildForm() {
    this.produtosForm = this.fb.group({
      nome: [''],
      descricao: [''],
      codigoBarras: [''],
      fabricanteID: [] // pega do cadastro de fabricante o id, use um select
    })
  }
}
